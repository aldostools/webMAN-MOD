package com.jhonju.ps3netsrv.server.commands;

import com.jhonju.ps3netsrv.server.Context;
import com.jhonju.ps3netsrv.server.exceptions.PS3NetSrvException;
import com.jhonju.ps3netsrv.server.io.IFile;

import com.jhonju.ps3netsrv.R;
import com.jhonju.ps3netsrv.server.utils.BinaryUtils;

import java.io.IOException;
import java.io.OutputStream;

public class ReadFileCommand extends AbstractCommand {
  protected final int numBytes;
  protected final long offset;

  public ReadFileCommand(Context ctx, int numBytes, long offset) {
    super(ctx);
    this.numBytes = numBytes;
    this.offset = offset;
  }

  @Override
  public void executeTask() throws IOException, PS3NetSrvException {
    if (numBytes < 0 || numBytes > BinaryUtils.BUFFER_SIZE || offset < 0) {
      send(ERROR_CODE_BYTEARRAY);
      return;
    }
    final int bytesRead;
    try {
      java.util.Set<IFile> files = ctx.getFile();
      if (files != null && !files.isEmpty()) {
        IFile file = files.iterator().next();
        bytesRead = numBytes == 0 ? 0 : Math.max(0, file.read(ctx.getOutputBuffer(), 0, numBytes, offset));
      } else {
        throw new IOException(ctx.getAndroidContext().getString(R.string.error_no_file_open));
      }
    } catch (IOException e) {
      send(ERROR_CODE_BYTEARRAY);
      throw new PS3NetSrvException(ctx.getAndroidContext().getString(R.string.error_read_file_generic));
    }
    // Socket failures must reach ContextHandler so the connection is closed.
    OutputStream os = ctx.getOutputStream();
    os.write(BinaryUtils.intToBytesBE(bytesRead));
    os.write(ctx.getOutputBuffer(), 0, bytesRead);
    os.flush();
  }
}
