package com.jhonju.ps3netsrv.server.commands;

import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import com.jhonju.ps3netsrv.server.Context;
import com.jhonju.ps3netsrv.server.exceptions.PS3NetSrvException;
import com.jhonju.ps3netsrv.server.io.DocumentFileCustom;
import com.jhonju.ps3netsrv.server.io.FileCustom;
import com.jhonju.ps3netsrv.server.io.IFile;
import com.jhonju.ps3netsrv.server.utils.BinaryUtils;
import com.jhonju.ps3netsrv.server.utils.FileLogger;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.LinkedHashSet;
import java.util.Set;

import com.jhonju.ps3netsrv.server.charset.StandardCharsets;

import com.jhonju.ps3netsrv.R;

public abstract class FileCommand extends AbstractCommand {
  protected final int filePathLength;
  protected String fileName;
  protected String requestedPath;
  // null: no virtual ISO prefix; true: PS3 image; false: data DVD image.
  protected Boolean virtualIsoPs3Mode;

  public FileCommand(Context ctx, short filePathLength) {
    super(ctx);
    this.filePathLength = filePathLength & 0xffff;
  }

  private String getFormattedPath(String path) {
    int end = path.length();
    while (end > 0 && path.charAt(end - 1) == '\0') end--;
    if (end < path.length()) path = path.substring(0, end);

    // Path Traversal Protection: Reject any path containing ".."
    if (path.contains("..")) {
      return null;
    }

    if (path.equals("/.") || path.equals("/"))
      path = "";
    if (path.startsWith("/"))
      path = path.substring(1);
    return path;
  }

  protected Set<IFile> getFile() throws IOException, PS3NetSrvException {
    return getFile(false);
  }

  protected Set<IFile> getFile(boolean resolveParent) throws IOException, PS3NetSrvException {
    ByteBuffer buffer = BinaryUtils.readCommandData(ctx.getInputStream(), this.filePathLength);
    if (buffer == null) {
      send(ERROR_CODE_BYTEARRAY);
      throw new PS3NetSrvException(ctx.getAndroidContext().getString(R.string.error_receiving_filename));
    }

    String path = new String(buffer.array(), StandardCharsets.UTF_8);

    // Strip Virtual ISO prefixes if present (based on C++ ps3netsrv implementation)
    if (path.startsWith("/***PS3***/")) {
      virtualIsoPs3Mode = true;
      path = path.substring(10);
    } else if (path.startsWith("/***DVD***/")) {
      virtualIsoPs3Mode = false;
      path = path.substring(10);
    }
    this.requestedPath = path;

    LinkedHashSet<IFile> files = new LinkedHashSet<>();

    String formattedPath = getFormattedPath(path);
    if (formattedPath == null) {
      send(ERROR_CODE_BYTEARRAY);
      throw new PS3NetSrvException(ctx.getAndroidContext().getString(R.string.error_invalid_path));
    }

    String childName;

    if (resolveParent) {
      if (formattedPath.endsWith("/")) {
        formattedPath = formattedPath.substring(0, formattedPath.length() - 1);
      }
      int lastSlash = formattedPath.lastIndexOf('/');
      if (lastSlash >= 0) {
        childName = formattedPath.substring(lastSlash + 1);
        formattedPath = formattedPath.substring(0, lastSlash);
      } else {
        childName = formattedPath;
        formattedPath = "";
      }
      this.fileName = childName;
    }

    try {
      for (String rootDirectory : ctx.getRootDirectories()) {
        if (rootDirectory.startsWith("content:")) {
          // Use SAF (DocumentFile)
          androidx.documentfile.provider.DocumentFile documentFile = androidx.documentfile.provider.DocumentFile
              .fromTreeUri(ctx.getAndroidContext(), Uri.parse(rootDirectory));
          if (documentFile == null || !documentFile.exists()) {
            continue;
          }

          if (!formattedPath.isEmpty()) {
            String[] paths = formattedPath.split("/");
            for (String s : paths) {
              if (s.isEmpty())
                continue;
            
              // Check for potential traversal in individual segments (redundant but safe)
              if (s.equals("..") || s.equals(".")) continue;

              DocumentFile found = findFileSafely(documentFile, s);
              if (found == null) {
                documentFile = null;
                break;
              }
              documentFile = found;
            }
          }

          if (documentFile != null && documentFile.exists()) {
            files.add(new DocumentFileCustom(documentFile, ctx.getContentResolver(), ctx.getAndroidContext()));
          }
        } else {
          // Use Standard File I/O
          java.io.File rootDir = new java.io.File(rootDirectory);
          java.io.File targetFile;
          if (formattedPath.isEmpty()) {
            targetFile = rootDir;
          } else {
            targetFile = new java.io.File(rootDir, formattedPath);
          }

          // Final security check: Ensure the canonical path still starts with the root directory
          try {
            String rootCanonical = rootDir.getCanonicalPath();
            String targetCanonical = targetFile.getCanonicalPath();
          
            String rootPrefix = rootCanonical.endsWith(java.io.File.separator)
                ? rootCanonical : rootCanonical + java.io.File.separator;
            if (!targetCanonical.equals(rootCanonical) && !targetCanonical.startsWith(rootPrefix)) {
              FileLogger.logWarning("Path traversal attempt blocked: " + path + " resolves to " + targetCanonical);
              continue;
            }
          
            if (targetFile.exists()) {
              files.add(new FileCustom(targetFile));
            }
          } catch (IOException e) {
            FileLogger.logError("Error resolving canonical path", e);
          }
        }
      }
      return files;
    } catch (IOException | RuntimeException | Error e) {
      Context.closeFiles(files);
      throw e;
    }
  }

  private DocumentFile findFileSafely(DocumentFile parent, String name) {
    if (parent == null)
      return null;

    // Fast path: Try direct lookup
    DocumentFile file = parent.findFile(name);
    if (file != null && file.exists()) {
      return file;
    }

    // Slow path: Iterate to find match (ignoring case)
    // This handles Android 14 SAF issues where findFile might fail or case differs
    DocumentFile[] files = parent.listFiles();
    for (DocumentFile f : files) {
      String fileName = f.getName();
      if (fileName != null && fileName.equalsIgnoreCase(name)) {
        return f;
      }
    }
    return null;
  }
}
