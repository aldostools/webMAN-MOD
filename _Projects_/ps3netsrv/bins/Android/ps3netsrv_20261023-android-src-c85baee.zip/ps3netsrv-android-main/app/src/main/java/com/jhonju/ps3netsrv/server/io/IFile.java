package com.jhonju.ps3netsrv.server.io;

import java.io.Closeable;
import java.io.IOException;

public interface IFile extends Closeable {
    boolean exists();
    boolean isFile();
    boolean isDirectory();
    boolean delete();
    long length();
    IFile[] listFiles() throws IOException;
    long lastModified();
    String getName();
    String[] list();
    IFile findFile(String fileName) throws IOException;
    default int read(byte[] buffer, long position) throws IOException {
        return read(buffer, 0, buffer.length, position);
    }
    int read(byte[] buffer, int offset, int length, long position) throws IOException;
    void write(byte[] buffer) throws IOException;
    boolean createDirectory(String name);
    boolean createFile(String name);
}
